# MIS Movies

MIS Movies is a modified, free and ad-free Android client based on Movie Box by R3AP3R Editz.

## Upstream attribution and license

This project retains the upstream source-available license and required attribution.

**Based on Movie Box by R3AP3R Editz**  
https://github.com/iotserver24/movie-box

The upstream license prohibits advertising, selling, subscriptions, paid hosted access, and paid feature unlocks for this software and its derivatives. Third-party media, catalogues, streams, and subtitles are not licensed by the app's source-code license.

## Android app identity

- Display name: MIS Movies
- Android application ID: `com.mis.movies`
- Flutter source package: `movie_box_app` (internal Dart package name retained to avoid unnecessary source churn)

## Build

See `docs/setup.md` and `docs/signing.md` for prerequisites, backend configuration, and release signing. Flutter/Dart and Android SDK are required to build the APK.
